package com.fundamental_b11.day3.oop.statictest;

public class TestStatic {
	
	public static void methodSatu() {
		System.out.println("Selamat Sore");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		methodSatu();
	}

}
