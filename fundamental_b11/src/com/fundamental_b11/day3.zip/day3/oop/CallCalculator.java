package com.fundamental_b11.day3.oop;

public class CallCalculator {

	public static void main(String[] args) {
		Calculator call = new Calculator();
		call.kurang();
	}
}
