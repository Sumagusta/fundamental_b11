package com.fundamental_b11.day3.oop.testmodifier;

import com.fundamental_b11.day3.oop.Calculator;

public class Method2 {

	public static void main(String[] args) {
		Calculator call = new Calculator();
		call.tambah();
	}
}
