package com.fundamental_b11.day3.oop.constructor;

public class Anak {
	
	public Anak() {
		System.out.println("BEKAL MAKAN SIANG");
	}
	
	public void Kakak() {
		System.out.println("Kakak Pertama");
	}
	
	public static void main(String[] args) {

	}
}
