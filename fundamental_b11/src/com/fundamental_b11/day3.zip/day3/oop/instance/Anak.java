package com.fundamental_b11.day3.oop.instance;

public class Anak {

	private void anakPertama() {
		// TODO Auto-generated method stub

		OrangTua warisan = new OrangTua();
		warisan.motor();
	}
	
	private void anakKedua() {
		// TODO Auto-generated method stub
		
		OrangTua warisan = new OrangTua();
		warisan.rumah();
	}
	
}
