package com.fundamental_b11.day3.oop.instance;

public class OrangTua {
	
	public void rumah() {
		System.out.println("Lantai 3");
	}
	
	public void motor() {
		System.out.println("Astrea");
	}
}
