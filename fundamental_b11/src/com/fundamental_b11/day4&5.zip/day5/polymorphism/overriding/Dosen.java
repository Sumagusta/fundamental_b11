package com.fundamental_b11.day5.polymorphism.overriding;

public class Dosen {
	
	public String name(String name) {
		return "Saya Dosen dan nama saya"+name;
	}
	
}
