package com.fundamental_b11.day5.polymorphism.overriding;

public class Kampus {

	public static void main(String[] args) {
		
		Dosen dosen = new Dosen();

	}

}
