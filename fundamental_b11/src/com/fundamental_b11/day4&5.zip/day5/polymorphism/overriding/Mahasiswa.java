package com.fundamental_b11.day5.polymorphism.overriding;

public class Mahasiswa {
	
	public String name(String name) {
		return "Saya Mahasiswa dan nama saya"+name;
	}
}
