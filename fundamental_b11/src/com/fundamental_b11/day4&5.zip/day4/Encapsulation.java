package com.fundamental_b11.day4;

public class Encapsulation {
	
	private String nama;
	private int usia;
	
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	public int getUsia() {
		return usia;
	}
	public void setUsia(int usia) {
		this.usia = usia;
	}
	
	
}
