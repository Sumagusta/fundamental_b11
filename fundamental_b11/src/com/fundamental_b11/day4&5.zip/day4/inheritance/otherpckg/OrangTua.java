package com.fundamental_b11.day4.inheritance.otherpckg;

public class OrangTua {

	public String rumah() {
		
		return "Rumah Kontrakan";
	}
	
	private void motor() {
		System.out.println("Vespa");
	}
	
	protected void perhiasan() {
		System.out.println("Emas 1 Kg");
	}
}
