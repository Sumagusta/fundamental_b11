package com.fundamental_b11.day4.inheritance;

import com.fundamental_b11.day4.inheritance.otherpckg.OrangTua;

public class Anak extends OrangTua {

	public void anakPertama() {
		Anak an = new Anak();
		an.perhiasan();
	}
	
}
