package com.fundamental_b11.day4.inheritance;

public interface Berkas {

	public void kartuKeluarga();
	public void ktp();
}
