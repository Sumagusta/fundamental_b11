package com.fundamental_b11.day4.inheritance;

public class Karyawan implements Kontrak, Berkas {

	@Override
	public void salary() {
		
	}

	@Override
	public void durasi() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void jamKerja() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void kartuKeluarga() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ktp() {
		// TODO Auto-generated method stub
		
	}

}
