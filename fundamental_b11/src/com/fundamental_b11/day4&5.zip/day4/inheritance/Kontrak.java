package com.fundamental_b11.day4.inheritance;

public interface Kontrak {

	public void salary();
	public void durasi();
	public void jamKerja();
}
