package com.fundamental_b11.day2.condition;

public class IfElseString {

	public static void main(String[] args) {

		String kondisi = "BeKerJa";
		
		if (kondisi.toLowerCase().equals("bekerja")) {
			System.out.println("Berusia 21 - selesai");
		}		
		else {
			System.out.println("Tidak ada kondisi yang sesuai");
		}

	}

}
