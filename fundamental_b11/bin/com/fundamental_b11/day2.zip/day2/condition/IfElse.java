package com.fundamental_b11.day2.condition;

public class IfElse {

	public static void main(String[] args) {

		int usia = 5;
		
		if (usia >=4) {
			System.out.println("TK Nol Kecil");
		}else if(usia == 5) {
			System.out.println("TK Nol Besar");
		}
		
		else {
			System.out.println("Tidak ada kondisi yang sesuai");
		}

	}

}
