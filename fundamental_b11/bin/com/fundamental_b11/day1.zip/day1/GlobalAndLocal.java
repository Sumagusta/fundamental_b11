package com.fundamental_b11.day1;

public class GlobalAndLocal {

	String globalData = "Global  Variable";
	
	public void method1() {
		String localData = "Local variable";
	}

}
