package com.fundamental_b11.day1;

public class KonversiData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String konversi = "1000";
		String konversi2 = "a1000";
		
		Integer result = Integer.valueOf(konversi);
		
		Integer result2 = Integer.valueOf(konversi2);
		
		System.out.println(result*2);
		
		System.out.println(result2);
	}

}
